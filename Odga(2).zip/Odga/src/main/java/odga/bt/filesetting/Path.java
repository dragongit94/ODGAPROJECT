package odga.bt.filesetting;

public class Path {
	public static final String FILE_STORE = "C:/Users/bit/Desktop/LZH/Spring/sts-bundle/workspace/Odga/src/main/webapp/resources/assets/img/profile/";
	public static final String FILE_REVIEW = "C:/Users/bit/Desktop/LZH/Spring/sts-bundle/workspace/Odga/src/main/webapp/resources/upload/";

}

